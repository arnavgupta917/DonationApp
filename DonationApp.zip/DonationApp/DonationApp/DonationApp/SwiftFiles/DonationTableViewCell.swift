//
//  DonationTableViewCell.swift
//  DonationApp
//
//  Created by Arnav Gupta on 8/8/18.
//  Copyright © 2018 NavAura. All rights reserved.
//

import Foundation
import UIKit

class DonationTableViewCell: UITableViewCell {
    @IBOutlet weak var noteTitleLabel: UILabel!
    @IBOutlet weak var noteModificationTimeLabel: UILabel!
    
}
