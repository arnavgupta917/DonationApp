//
//  charitySelector.swift
//  DonationApp
//
//  Created by Arnav Gupta on 7/30/18.
//  Copyright © 2018 NavAura. All rights reserved.
//

import Foundation
import UIKit




class charitySelector: UIViewController {
    
    var tagOfButton: Int = 0
    var donateURL: URL!
    
    @IBOutlet weak var homeofhopeButton: UIButton!
    @IBOutlet weak var americanredcrossButton: UIButton!
    @IBOutlet weak var goodwillButton: UIButton!
    @IBOutlet weak var makeawishButton: UIButton!
    @IBOutlet weak var svcButton: UIButton!
    @IBOutlet weak var drButton: UIButton!
    @IBOutlet weak var oxfamButton: UIButton!
    @IBOutlet weak var globalButton: UIButton!
    @IBOutlet weak var salvationButton: UIButton!
    @IBOutlet weak var hforhbutton: UIButton!
    @IBOutlet weak var unicefButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "ombre.png")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        setUpViews()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func setUpViews() {
        homeofhopeButton.layer.cornerRadius = 8
        homeofhopeButton.layer.masksToBounds = true
        
        americanredcrossButton.layer.cornerRadius = 8
        americanredcrossButton.layer.masksToBounds = true
        
        globalButton.layer.cornerRadius = 8
        globalButton.layer.masksToBounds = true
        
        goodwillButton.layer.cornerRadius = 8
        goodwillButton.layer.masksToBounds = true
        
        makeawishButton.layer.cornerRadius = 8
        makeawishButton.layer.masksToBounds = true
        
        svcButton.layer.cornerRadius = 8
        svcButton.layer.masksToBounds = true
        
        drButton.layer.cornerRadius = 8
        drButton.layer.masksToBounds = true
        
        oxfamButton.layer.cornerRadius = 8
        oxfamButton.layer.masksToBounds = true
        
    }
    
    
    @IBAction func cantFindButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "toTableView", sender: self)
        
    }
    
    
    @IBAction func pressedCharityButton(_ button: UIButton) {

        
        tagOfButton = button.tag
        if tagOfButton == 0
        {
            donateURL = URL(string:"http://www.hohinc.org/donate.html")
        }
        
        if tagOfButton == 1
        {
            donateURL = URL(string:"https://www.redcross.org/donate/donation")
        }
        
        if tagOfButton == 2
        {
            donateURL = URL(string: "https://sfgoodwill.org/donate/donate-money/?gclid=CjwKCAjwkYDbBRB6EiwAR0T_-iOBAsC-e0i-9qDmNYnFnH93CDtE7Qx59I3W-dMSkELz8HPei0OcsRoCkOQQAvD_BwE")
        }
        
        if tagOfButton == 3
        {
            donateURL = URL(string: "https://secure2.wish.org/site/SPageServer?pagename=donate_now&chid=100-000")
        }
        
        if tagOfButton == 4
        {
            donateURL = URL(string: "https://support.savethechildren.org/site/Donation2?df_id=1620&1620.donation=form1")
        }
        
        if tagOfButton == 5
        {
            donateURL = URL(string:"https://secure.directrelief.org/site/Donation2;jsessionid=00000000.app260b?idb=1215695458&df_id=2924&mfc_pref=T&2924.donation=form1&NONCE_TOKEN=FCC177F3C1B518657FD726EBB8C6EEED&2924_donation=form1")
        }
        
        if tagOfButton == 6
        {
            donateURL = URL(string:"https://secure2.oxfamamerica.org/page/contribute/donate")
        }
        
        if tagOfButton == 7
        {
            donateURL = URL(string:"https://www.globalgiving.org/dy/v2/checkout/billing/")
        }
        
        if tagOfButton == 8
        {
            donateURL = URL(string:"https://secure20.salvationarmy.org/donation.jsp")
        }
        
        if tagOfButton == 9
        {
            donateURL = URL(string: "https://www.habitat.org/donate/")
        }
        
        if tagOfButton == 10
        {
            donateURL = URL(string: "https://donate.unicefusa.org/page/contribute/help-save-childrens-lives-29161?ms=referral_dig_2018_misc_20180322_topnav_button_BSD_None&initialms=referral_dig_2018_mis&ms=ref_dig_2015_web_header_donate&_ga=2.225818066.915109111.1533424476-746299616.1533424476" )
        }
        if UIApplication.shared.canOpenURL(donateURL!) {
            UIApplication.shared.open(donateURL!, options: [:], completionHandler: nil)
            //If you want handle the completion block than
            UIApplication.shared.open(donateURL!, options: [:], completionHandler: { (success) in
                print("Open url : \(success)")
            })
        }
        
    }
    
    
    @IBAction func backButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "toOptions", sender: self)
    }
    
    
    
    
}
